package net.minecraft.src;

class RedstoneUpdateInfo {
	int x;
	int y;
	int z;
	long updateTime;

	public RedstoneUpdateInfo(int var1, int var2, int var3, long var4) {
		this.x = var1;
		this.y = var2;
		this.z = var3;
		this.updateTime = var4;
	}
}
