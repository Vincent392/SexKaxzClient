package net.minecraft.src;

enum EnumOSIsom {
	linux,
	solaris,
	windows,
	macos,
	unknown;
}
