package net.minecraft.src;

public class ModelPig extends ModelQuadraped {
	public ModelPig() {
		super(6, 0.0F);
	}

	public ModelPig(float var1) {
		super(6, var1);
	}
}
