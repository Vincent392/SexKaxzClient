package net.minecraft.src;

import java.io.File;
import java.util.Random;
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.codecs.CodecJOrbis;
import paulscode.sound.codecs.CodecWav;
import paulscode.sound.libraries.LibraryLWJGLOpenAL;

public class SoundManager {
	private SoundSystem sndSystem;
	private SoundPool soundPoolSounds = new SoundPool();
	private SoundPool soundPoolStreaming = new SoundPool();
	private SoundPool soundPoolMusic = new SoundPool();
	private int playedSoundsCount = 0;
	private GameSettings options;
	private boolean loaded = false;
	private Random rand = new Random();
	private int ticksBeforeMusic = this.rand.nextInt(12000);

	public void loadSoundSettings(GameSettings var1) {
		this.soundPoolStreaming.isGetRandomSound = false;
		this.options = var1;
		if(!this.loaded && (var1 == null || var1.b || var1.a)) {
			this.tryToSetLibraryAndCodecs();
		}

	}

	private void tryToSetLibraryAndCodecs() {
		try {
			boolean var1 = this.options.b;
			boolean var2 = this.options.a;
			this.options.b = false;
			this.options.a = false;
			this.options.saveOptions();
			SoundSystemConfig.addLibrary(LibraryLWJGLOpenAL.class);
			SoundSystemConfig.setCodec("ogg", CodecJOrbis.class);
			SoundSystemConfig.setCodec("mus", CodecMus.class);
			SoundSystemConfig.setCodec("wav", CodecWav.class);
			this.sndSystem = new SoundSystem();
			this.options.b = var1;
			this.options.a = var2;
			this.options.saveOptions();
		} catch (Throwable var3) {
			var3.printStackTrace();
			System.err.println("error linking with the LibraryJavaSound plug-in");
		}

		this.loaded = true;
	}

	public void onSoundOptionsChanged() {
		if(!this.loaded && (this.options.b || this.options.a)) {
			this.tryToSetLibraryAndCodecs();
		}

		if(!this.options.a) {
			this.sndSystem.stop("BgMusic");
		}

	}

	public void closeMinecraft() {
		if(this.loaded) {
			this.sndSystem.cleanup();
		}

	}

	public void addSound(String var1, File var2) {
		this.soundPoolSounds.addSound(var1, var2);
	}

	public void addStreaming(String var1, File var2) {
		this.soundPoolStreaming.addSound(var1, var2);
	}

	public void addMusic(String var1, File var2) {
		this.soundPoolMusic.addSound(var1, var2);
	}

	public void playRandomMusicIfReady() {
		if(this.loaded && this.options.a) {
			if(!this.sndSystem.playing("BgMusic") && !this.sndSystem.playing("streaming")) {
				if(this.ticksBeforeMusic > 0) {
					--this.ticksBeforeMusic;
					return;
				}

				SoundPoolEntry var1 = this.soundPoolMusic.getRandomSound();
				if(var1 != null) {
					this.ticksBeforeMusic = this.rand.nextInt(24000) + 24000;
					this.sndSystem.backgroundMusic("BgMusic", var1.soundUrl, var1.soundName, false);
					this.sndSystem.play("BgMusic");
				}
			}

		}
	}

	public void setListener(EntityLiving var1, float var2) {
		if(this.loaded && this.options.b) {
			if(var1 != null) {
				float var3 = var1.prevRotationYaw + (var1.rotationYaw - var1.prevRotationYaw) * var2;
				double var4 = var1.prevPosX + (var1.posX - var1.prevPosX) * (double)var2;
				double var6 = var1.prevPosY + (var1.posY - var1.prevPosY) * (double)var2;
				double var8 = var1.prevPosZ + (var1.posZ - var1.prevPosZ) * (double)var2;
				float var10 = MathHelper.cos(-var3 * 0.017453292F - 3.1415927F);
				float var11 = MathHelper.sin(-var3 * 0.017453292F - 3.1415927F);
				float var12 = -var11;
				float var13 = 0.0F;
				float var14 = -var10;
				float var15 = 0.0F;
				float var16 = 1.0F;
				float var17 = 0.0F;
				this.sndSystem.setListenerPosition((float)var4, (float)var6, (float)var8);
				this.sndSystem.setListenerOrientation(var12, var13, var14, var15, var16, var17);
			}
		}
	}

	public void playStreaming(String var1, float var2, float var3, float var4, float var5, float var6) {
		if(this.loaded && this.options.b) {
			String var7 = "streaming";
			if(this.sndSystem.playing("streaming")) {
				this.sndSystem.stop("streaming");
			}

			if(var1 != null) {
				SoundPoolEntry var8 = this.soundPoolStreaming.getRandomSoundFromSoundPool(var1);
				if(var8 != null && var5 > 0.0F) {
					if(this.sndSystem.playing("BgMusic")) {
						this.sndSystem.stop("BgMusic");
					}

					float var9 = 16.0F;
					this.sndSystem.newStreamingSource(true, var7, var8.soundUrl, var8.soundName, false, var2, var3, var4, 2, var9 * 4.0F);
					this.sndSystem.setVolume(var7, 0.5F);
					this.sndSystem.play(var7);
				}

			}
		}
	}

	public void playSound(String var1, float var2, float var3, float var4, float var5, float var6) {
		if(this.loaded && this.options.b) {
			SoundPoolEntry var7 = this.soundPoolSounds.getRandomSoundFromSoundPool(var1);
			if(var7 != null && var5 > 0.0F) {
				this.playedSoundsCount = (this.playedSoundsCount + 1) % 256;
				String var8 = "sound_" + this.playedSoundsCount;
				float var9 = 16.0F;
				if(var5 > 1.0F) {
					var9 *= var5;
				}

				this.sndSystem.newSource(var5 > 1.0F, var8, var7.soundUrl, var7.soundName, false, var2, var3, var4, 2, var9);
				this.sndSystem.setPitch(var8, var6);
				if(var5 > 1.0F) {
					var5 = 1.0F;
				}

				this.sndSystem.setVolume(var8, var5);
				this.sndSystem.play(var8);
			}

		}
	}

	public void playSoundFX(String var1, float var2, float var3) {
		if(this.loaded && this.options.b) {
			SoundPoolEntry var4 = this.soundPoolSounds.getRandomSoundFromSoundPool(var1);
			if(var4 != null) {
				this.playedSoundsCount = (this.playedSoundsCount + 1) % 256;
				String var5 = "sound_" + this.playedSoundsCount;
				this.sndSystem.newSource(false, var5, var4.soundUrl, var4.soundName, false, 0.0F, 0.0F, 0.0F, 0, 0.0F);
				if(var2 > 1.0F) {
					var2 = 1.0F;
				}

				var2 *= 0.25F;
				this.sndSystem.setPitch(var5, var3);
				this.sndSystem.setVolume(var5, var2);
				this.sndSystem.play(var5);
			}

		}
	}
}
