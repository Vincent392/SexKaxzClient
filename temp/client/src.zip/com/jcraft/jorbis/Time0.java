package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Time0 extends FuncTime {
	void pack(Object var1, Buffer var2) {
	}

	Object unpack(Info var1, Buffer var2) {
		return "";
	}

	Object look(DspState var1, InfoMode var2, Object var3) {
		return "";
	}

	void free_info(Object var1) {
	}

	void free_look(Object var1) {
	}

	int inverse(Block var1, Object var2, float[] var3, float[] var4) {
		return 0;
	}
}
